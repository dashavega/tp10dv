import { Component } from '@angular/core';

@Component({
  selector: 'app-usuario',
  standalone: true,
  imports: [],
  templateUrl: './usuario.component.html',
  styleUrl: './usuario.component.css'
})
export class UsuarioComponent {
  Usuario = {
    Nombre: "Jenaro",
    Apellido: "Lara",
    NombreUsuario: "JenaLara",
    Password:"1234567",
    TipoUsuario:"Cliente",
    Estado:"",
  }
  saludar() {
    return `hola ${this.Usuario.Nombre}`
  }
  MostrarInfo(){
    return `El nombre es: ${this.Usuario.Nombre} ${this.Usuario.Apellido} Y es un ${this.Usuario.TipoUsuario}`
  }
}
