import { LocationUpgradeModule } from '@angular/common/upgrade';
import { Component } from '@angular/core';

@Component({
  selector: 'app-articulos',
  standalone: true,
  imports: [],
  templateUrl: './articulos.component.html',
  styleUrl: './articulos.component.css'
})
export class ArticulosComponent {
  articulo= {
    codigo:"129834192",
    nomarticulo:"Jabon",
    descripcion:"El jabón es un producto de limpieza que se obtiene de la combinación de grasas, una base y agua. Se puede encontrar en diferentes presentaciones, como líquido, en barra, en polvo, en crema, entre otras.",
    marca:"Ariel",
    cantidad:"10",
    precio:"15.000",
    estado:""
  }
}
