import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { InterpolacionComponent } from './interpolacion/interpolacion.component';
import { UsuarioComponent } from './usuario/usuario.component';
import { VendedorComponent } from './vendedor/vendedor.component';
import { ArticulosComponent } from './articulos/articulos.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet,InterpolacionComponent,UsuarioComponent,VendedorComponent,ArticulosComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'aplicacioninterpolacion';
}
