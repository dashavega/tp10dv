import { Component } from '@angular/core';

@Component({
  selector: 'app-vendedor',
  standalone: true,
  imports: [],
  templateUrl: './vendedor.component.html',
  styleUrl: './vendedor.component.css'
})
export class VendedorComponent {
  vendedor={
    idvendedor:"8912358",
    usuarionombre:"Jenaro",
    password:"129492",
    nombre:"jenaro",
    apellido:"lara",
    edad:"18",
    direccion:"cipolletti",
    sueldo:1900000,
    telefono:"2997781223",
    email:"jenarolaraa@gmail.com",
    instagram:"jenarolaraa",
  }
  sumarVeinte(){
    var suma=(this.vendedor.edad + 20);
  }
  incrementarSueldo(){
    var porcentaje=(this.vendedor.sueldo*1.10)
    var sueldo=(this.vendedor.sueldo+porcentaje)
  }
}
